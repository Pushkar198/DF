import { GoogleGenAI } from "@google/genai";
import { EnvironmentalData } from "@shared/schema";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface DiseaseRiskData {
  historicalData: {
    disease: string;
    occurrences: number;
    season: string;
    year: number;
  }[];
  environmentalData: EnvironmentalData;
  socialData: {
    newsArticles: string[];
    socialMediaMentions: number;
    healthSearches: number;
  };
  region: string;
  state: string;
  season: string;
}

export interface DiseasePrediction {
  disease: string;
  riskLevel: "low" | "medium" | "high";
  confidence: number;
  predictedTimeframe: string;
  contributingFactors: string[];
  recommendedActions: string[];
  medicines: string[];
}

export interface PredictionResponse {
  predictions: DiseasePrediction[];
  overallRisk: "low" | "medium" | "high";
  summary: string;
  dataSourcesUsed: string[];
}

export async function generateDiseasePrediction(
  data: DiseaseRiskData
): Promise<PredictionResponse> {
  try {
    const systemPrompt = `You are an expert epidemiologist AI system specialized in predicting disease outbreaks. 
    
    Analyze the provided data and predict disease risks for the specified region and timeframe.
    
    Consider:
    1. Historical disease patterns and seasonal trends
    2. Environmental factors (temperature, humidity, rainfall, floods, air quality)
    3. Social indicators (news mentions, health searches, social media activity)
    4. Regional characteristics and population density
    5. Current season and upcoming weather patterns
    
    Provide predictions with:
    - Risk level (low/medium/high) with confidence percentage
    - Timeframe for potential outbreak
    - Key contributing factors
    - Recommended preventive actions
    - Suggested medicines for preparation
    
    Focus on diseases common in India, especially:
    - Dengue, Malaria, Chikungunya (monsoon)
    - Typhoid, Cholera, Hepatitis A (contaminated water)
    - Seasonal Flu, Pneumonia (winter)
    - Heat stroke, Dehydration (summer)
    
    Respond in JSON format matching the PredictionResponse schema.`;

    const userPrompt = `Analyze the following data for disease risk prediction:

    Region: ${data.region}, ${data.state}
    Current Season: ${data.season}
    
    Historical Disease Data:
    ${JSON.stringify(data.historicalData, null, 2)}
    
    Environmental Data:
    - Temperature: ${data.environmentalData.temperature}°C
    - Humidity: ${data.environmentalData.humidity}%
    - Rainfall: ${data.environmentalData.rainfall}mm
    - Wind Speed: ${data.environmentalData.windSpeed} km/h
    - Air Quality: ${data.environmentalData.airQuality}
    - Flood Alert: ${data.environmentalData.floodAlert}
    - Heatwave Alert: ${data.environmentalData.heatwaveAlert}
    
    Social Data:
    - News Articles: ${data.socialData.newsArticles.join(', ')}
    - Social Media Mentions: ${data.socialData.socialMediaMentions}
    - Health-related Searches: ${data.socialData.healthSearches}
    
    Please provide comprehensive disease risk predictions for the next 30 days.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  disease: { type: "string" },
                  riskLevel: { type: "string", enum: ["low", "medium", "high"] },
                  confidence: { type: "number" },
                  predictedTimeframe: { type: "string" },
                  contributingFactors: {
                    type: "array",
                    items: { type: "string" }
                  },
                  recommendedActions: {
                    type: "array",
                    items: { type: "string" }
                  },
                  medicines: {
                    type: "array",
                    items: { type: "string" }
                  }
                },
                required: ["disease", "riskLevel", "confidence", "predictedTimeframe", "contributingFactors", "recommendedActions", "medicines"]
              }
            },
            overallRisk: { type: "string", enum: ["low", "medium", "high"] },
            summary: { type: "string" },
            dataSourcesUsed: {
              type: "array",
              items: { type: "string" }
            }
          },
          required: ["predictions", "overallRisk", "summary", "dataSourcesUsed"]
        },
      },
      contents: userPrompt,
    });

    const rawJson = response.text;
    console.log(`Gemini Raw Response: ${rawJson}`);

    if (rawJson) {
      const predictionData: PredictionResponse = JSON.parse(rawJson);
      return predictionData;
    } else {
      throw new Error("Empty response from Gemini model");
    }
  } catch (error) {
    console.error("Error in generateDiseasePrediction:", error);
    throw new Error(`Failed to generate disease prediction: ${error}`);
  }
}

export async function generateMedicineRecommendations(
  disease: string,
  severity: string,
  patientProfile: string
): Promise<{
  primaryMedicines: string[];
  alternativeMedicines: string[];
  dosageInstructions: string[];
  precautions: string[];
}> {
  try {
    const systemPrompt = `You are a medical AI assistant specializing in pharmacology and treatment recommendations.
    
    Provide evidence-based medicine recommendations for the given disease and patient profile.
    Consider:
    1. Primary treatment options
    2. Alternative medicines
    3. Dosage guidelines
    4. Precautions and contraindications
    5. Disease severity level
    
    Focus on medicines commonly available in India and follow Indian medical guidelines.
    
    Respond in JSON format with the specified schema.`;

    const userPrompt = `Provide medicine recommendations for:
    
    Disease: ${disease}
    Severity: ${severity}
    Patient Profile: ${patientProfile}
    
    Include both primary and alternative treatment options with proper dosage guidance.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            primaryMedicines: {
              type: "array",
              items: { type: "string" }
            },
            alternativeMedicines: {
              type: "array",
              items: { type: "string" }
            },
            dosageInstructions: {
              type: "array",
              items: { type: "string" }
            },
            precautions: {
              type: "array",
              items: { type: "string" }
            }
          },
          required: ["primaryMedicines", "alternativeMedicines", "dosageInstructions", "precautions"]
        },
      },
      contents: userPrompt,
    });

    const rawJson = response.text;
    
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from Gemini model");
    }
  } catch (error) {
    console.error("Error in generateMedicineRecommendations:", error);
    throw new Error(`Failed to generate medicine recommendations: ${error}`);
  }
}
