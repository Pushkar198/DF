import { storage } from "../storage";
import { InsertDisease, InsertMedicine } from "@shared/schema";

export class DataSeeder {
  async seedInitialData() {
    try {
      await this.seedDiseases();
      await this.seedMedicines();
      await this.seedDiseaseMedicineLinks();
      console.log("Initial data seeded successfully");
    } catch (error) {
      console.error("Error seeding initial data:", error);
    }
  }

  private async seedDiseases() {
    const diseases: InsertDisease[] = [
      {
        name: "Dengue",
        description: "Mosquito-borne viral infection causing fever, headache, and muscle pain",
        symptoms: ["High fever", "Severe headache", "Muscle and joint pain", "Nausea", "Vomiting", "Skin rash"],
        riskFactors: ["Stagnant water", "Monsoon season", "Poor sanitation", "Urban areas"],
        seasonalPattern: "monsoon",
        severity: "high",
      },
      {
        name: "Malaria",
        description: "Mosquito-borne disease caused by Plasmodium parasites",
        symptoms: ["Fever", "Chills", "Headache", "Sweating", "Fatigue", "Nausea"],
        riskFactors: ["Stagnant water", "Poor drainage", "Tropical climate", "Inadequate bed nets"],
        seasonalPattern: "monsoon",
        severity: "high",
      },
      {
        name: "Seasonal Flu",
        description: "Viral infection affecting the respiratory system",
        symptoms: ["Fever", "Cough", "Sore throat", "Runny nose", "Body aches", "Fatigue"],
        riskFactors: ["Cold weather", "Crowded places", "Weak immunity", "Poor ventilation"],
        seasonalPattern: "winter",
        severity: "medium",
      },
      {
        name: "Typhoid",
        description: "Bacterial infection spread through contaminated food and water",
        symptoms: ["Prolonged fever", "Headache", "Abdominal pain", "Diarrhea", "Weakness"],
        riskFactors: ["Contaminated water", "Poor sanitation", "Unhygienic food", "Hot weather"],
        seasonalPattern: "summer",
        severity: "high",
      },
      {
        name: "Cholera",
        description: "Waterborne bacterial infection causing severe diarrhea",
        symptoms: ["Severe diarrhea", "Vomiting", "Dehydration", "Muscle cramps", "Rapid heart rate"],
        riskFactors: ["Contaminated water", "Poor sanitation", "Flooding", "Overcrowding"],
        seasonalPattern: "monsoon",
        severity: "high",
      },
      {
        name: "Chikungunya",
        description: "Mosquito-borne viral disease causing joint pain",
        symptoms: ["Joint pain", "Fever", "Headache", "Muscle pain", "Nausea", "Rash"],
        riskFactors: ["Aedes mosquitoes", "Stagnant water", "Urban areas", "Poor vector control"],
        seasonalPattern: "monsoon",
        severity: "medium",
      },
      {
        name: "Pneumonia",
        description: "Infection causing inflammation of lung tissue",
        symptoms: ["Cough", "Chest pain", "Difficulty breathing", "Fever", "Fatigue"],
        riskFactors: ["Cold weather", "Weak immunity", "Air pollution", "Smoking"],
        seasonalPattern: "winter",
        severity: "high",
      },
      {
        name: "Hepatitis A",
        description: "Viral liver infection spread through contaminated food/water",
        symptoms: ["Jaundice", "Fatigue", "Nausea", "Abdominal pain", "Loss of appetite"],
        riskFactors: ["Contaminated food", "Poor hygiene", "Unsafe water", "Overcrowding"],
        seasonalPattern: "summer",
        severity: "medium",
      },
    ];

    for (const disease of diseases) {
      try {
        await storage.createDisease(disease);
        console.log(`Seeded disease: ${disease.name}`);
      } catch (error) {
        console.log(`Disease ${disease.name} already exists or error occurred`);
      }
    }
  }

  private async seedMedicines() {
    const medicines: InsertMedicine[] = [
      {
        name: "Paracetamol",
        genericName: "Acetaminophen",
        category: "antipyretic",
        dosage: "500mg-1000mg every 6 hours",
        sideEffects: ["Liver damage (with overdose)", "Allergic reactions"],
        contraindications: ["Severe liver disease", "Alcohol dependency"],
      },
      {
        name: "Artemether",
        genericName: "Artemether",
        category: "antimalarial",
        dosage: "80mg twice daily for 3 days",
        sideEffects: ["Nausea", "Vomiting", "Dizziness", "Headache"],
        contraindications: ["Pregnancy (first trimester)", "Severe kidney disease"],
      },
      {
        name: "Oseltamivir",
        genericName: "Oseltamivir phosphate",
        category: "antiviral",
        dosage: "75mg twice daily for 5 days",
        sideEffects: ["Nausea", "Vomiting", "Headache", "Fatigue"],
        contraindications: ["Severe kidney disease", "Hypersensitivity"],
      },
      {
        name: "Azithromycin",
        genericName: "Azithromycin",
        category: "antibiotic",
        dosage: "500mg once daily for 3 days",
        sideEffects: ["Nausea", "Diarrhea", "Abdominal pain"],
        contraindications: ["Liver disease", "Myasthenia gravis"],
      },
      {
        name: "ORS",
        genericName: "Oral Rehydration Solution",
        category: "rehydration",
        dosage: "1 packet in 200ml water as needed",
        sideEffects: ["Vomiting (if taken too quickly)"],
        contraindications: ["Severe dehydration requiring IV fluids"],
      },
      {
        name: "Chloroquine",
        genericName: "Chloroquine phosphate",
        category: "antimalarial",
        dosage: "600mg base, then 300mg after 6-8 hours",
        sideEffects: ["Nausea", "Headache", "Dizziness", "Blurred vision"],
        contraindications: ["Retinal disease", "Psoriasis"],
      },
      {
        name: "Doxycycline",
        genericName: "Doxycycline hyclate",
        category: "antibiotic",
        dosage: "100mg twice daily",
        sideEffects: ["Nausea", "Photosensitivity", "Esophageal irritation"],
        contraindications: ["Pregnancy", "Children under 8 years"],
      },
      {
        name: "Ceftriaxone",
        genericName: "Ceftriaxone sodium",
        category: "antibiotic",
        dosage: "1-2g IV/IM once daily",
        sideEffects: ["Injection site reactions", "Diarrhea", "Rash"],
        contraindications: ["Penicillin allergy", "Severe kidney disease"],
      },
      {
        name: "Prednisolone",
        genericName: "Prednisolone",
        category: "corticosteroid",
        dosage: "5-60mg daily depending on condition",
        sideEffects: ["Weight gain", "Mood changes", "Increased infection risk"],
        contraindications: ["Systemic fungal infections", "Live vaccines"],
      },
      {
        name: "Zinc Sulfate",
        genericName: "Zinc sulfate",
        category: "supplement",
        dosage: "20mg daily for 10-14 days",
        sideEffects: ["Nausea", "Metallic taste", "Stomach upset"],
        contraindications: ["Copper deficiency", "Sideroblastic anemia"],
      },
    ];

    for (const medicine of medicines) {
      try {
        await storage.createMedicine(medicine);
        console.log(`Seeded medicine: ${medicine.name}`);
      } catch (error) {
        console.log(`Medicine ${medicine.name} already exists or error occurred`);
      }
    }
  }

  private async seedDiseaseMedicineLinks() {
    // This would typically be done through a separate table/relation
    // For now, we'll handle this in the medicine recommendations logic
    console.log("Disease-medicine links handled in recommendation logic");
  }
}

export const dataSeeder = new DataSeeder();
