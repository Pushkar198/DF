import { storage } from "../storage";
import { generateDiseasePrediction, DiseaseRiskData, PredictionResponse } from "./gemini";
import { Disease, InsertPrediction, InsertAlert, EnvironmentalData } from "@shared/schema";

export class PredictionService {
  async generatePredictions(userId: number, region: string, state: string): Promise<void> {
    try {
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        throw new Error("User not found");
      }

      // Get environmental data
      const environmentalData = await storage.getLatestEnvironmentalData(region);
      if (!environmentalData) {
        throw new Error("Environmental data not available for region");
      }

      // Get historical disease data (mock for now - would integrate with real data sources)
      const historicalData = await this.getHistoricalDiseaseData(region, state);
      
      // Get social data (mock for now - would integrate with social media APIs)
      const socialData = await this.getSocialData(region);
      
      // Determine current season
      const currentSeason = this.getCurrentSeason();
      
      // Prepare data for Gemini
      const riskData: DiseaseRiskData = {
        historicalData,
        environmentalData,
        socialData,
        region,
        state,
        season: currentSeason,
      };

      // Generate predictions using Gemini
      const predictionResponse = await generateDiseasePrediction(riskData);
      
      // Store predictions in database
      await this.storePredictions(userId, region, state, predictionResponse, riskData);
      
      console.log(`Generated predictions for user ${userId} in ${region}, ${state}`);
    } catch (error) {
      console.error("Error generating predictions:", error);
      throw error;
    }
  }

  private async getHistoricalDiseaseData(region: string, state: string) {
    // Mock historical data - in production, this would query real databases
    const currentYear = new Date().getFullYear();
    const currentSeason = this.getCurrentSeason();
    
    return [
      {
        disease: "Dengue",
        occurrences: currentSeason === "monsoon" ? 150 : 50,
        season: "monsoon",
        year: currentYear - 1,
      },
      {
        disease: "Malaria",
        occurrences: currentSeason === "monsoon" ? 100 : 30,
        season: "monsoon",
        year: currentYear - 1,
      },
      {
        disease: "Seasonal Flu",
        occurrences: currentSeason === "winter" ? 200 : 80,
        season: "winter",
        year: currentYear - 1,
      },
      {
        disease: "Typhoid",
        occurrences: currentSeason === "summer" ? 75 : 25,
        season: "summer",
        year: currentYear - 1,
      },
    ];
  }

  private async getSocialData(region: string) {
    // Mock social data - in production, this would integrate with social media APIs
    return {
      newsArticles: [
        "Monsoon health advisory issued for " + region,
        "Dengue cases rising in urban areas",
        "Health department issues prevention guidelines",
      ],
      socialMediaMentions: 150,
      healthSearches: 300,
    };
  }

  private getCurrentSeason(): string {
    const month = new Date().getMonth() + 1; // 1-12
    
    if (month >= 12 || month <= 2) {
      return "winter";
    } else if (month >= 3 && month <= 5) {
      return "summer";
    } else if (month >= 6 && month <= 9) {
      return "monsoon";
    } else {
      return "post-monsoon";
    }
  }

  private async storePredictions(
    userId: number,
    region: string,
    state: string,
    predictionResponse: PredictionResponse,
    riskData: DiseaseRiskData
  ) {
    // Get all diseases from database
    const diseases = await storage.getAllDiseases();
    
    for (const prediction of predictionResponse.predictions) {
      // Find disease in database
      const disease = diseases.find(d => 
        d.name.toLowerCase() === prediction.disease.toLowerCase()
      );
      
      if (!disease) {
        console.warn(`Disease not found in database: ${prediction.disease}`);
        continue;
      }

      // Calculate predicted date
      const predictedDate = new Date();
      if (prediction.predictedTimeframe.includes("15 days")) {
        predictedDate.setDate(predictedDate.getDate() + 15);
      } else if (prediction.predictedTimeframe.includes("30 days")) {
        predictedDate.setDate(predictedDate.getDate() + 30);
      } else {
        predictedDate.setDate(predictedDate.getDate() + 7); // Default to 7 days
      }

      // Create prediction record
      const predictionRecord: InsertPrediction = {
        diseaseId: disease.id,
        region,
        state,
        riskLevel: prediction.riskLevel,
        confidence: prediction.confidence.toString(),
        predictedDate,
        contributingFactors: {
          factors: prediction.contributingFactors,
          actions: prediction.recommendedActions,
          medicines: prediction.medicines,
        },
        geminiResponse: predictionResponse,
        environmentalData: riskData.environmentalData,
        socialData: riskData.socialData,
      };

      const savedPrediction = await storage.createPrediction({
        ...predictionRecord,
        userId,
      });

      // Create alert if risk is medium or high
      if (prediction.riskLevel === "medium" || prediction.riskLevel === "high") {
        const alertSeverity = prediction.riskLevel === "high" ? "high" : "medium";
        
        const alert: InsertAlert = {
          predictionId: savedPrediction.id,
          title: `${prediction.riskLevel.toUpperCase()} Risk Alert: ${prediction.disease}`,
          message: `${prediction.disease} outbreak predicted for ${region} in ${prediction.predictedTimeframe}. Contributing factors: ${prediction.contributingFactors.join(", ")}`,
          severity: alertSeverity,
        };

        await storage.createAlert({
          ...alert,
          userId,
        });
      }
    }
  }

  async updateEnvironmentalData(region: string, state: string) {
    // Mock environmental data update - in production, this would integrate with weather APIs
    const mockEnvironmentalData = {
      region,
      state,
      temperature: "32",
      humidity: "78",
      rainfall: "45",
      windSpeed: "12",
      airQuality: "Moderate",
      floodAlert: false,
      heatwaveAlert: false,
      dataSource: "Weather API",
      recordedAt: new Date(),
    };

    await storage.createEnvironmentalData(mockEnvironmentalData);
  }
}

export const predictionService = new PredictionService();
