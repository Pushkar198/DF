import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { predictionService } from "./services/prediction";
import { dataSeeder } from "./services/data-seeder";
import { insertUserSchema, insertAlertSchema, insertEnvironmentalDataSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import session from "express-session";
import { z } from "zod";

// Session configuration
declare module "express-session" {
  interface SessionData {
    userId: number;
    userRole: string;
    username: string;
  }
}

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const registerSchema = insertUserSchema.extend({
  email: z.string().email(),
  password: z.string().min(6),
  confirmPassword: z.string().min(6),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize database with seed data
  await dataSeeder.seedInitialData();

  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || "your-secret-key-change-in-production",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
    },
  }));

  // Auth middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    next();
  };

  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.session.userId || req.session.userRole !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(400).json({ error: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...data,
        password: hashedPassword,
      });

      // Set session
      req.session.userId = user.id;
      req.session.userRole = user.role;
      req.session.username = user.username;

      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          email: user.email, 
          role: user.role,
          organizationType: user.organizationType,
          organizationName: user.organizationName,
          region: user.region,
          state: user.state,
        } 
      });
    } catch (error) {
      console.error("Registration error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Check password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Set session
      req.session.userId = user.id;
      req.session.userRole = user.role;
      req.session.username = user.username;

      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          email: user.email, 
          role: user.role,
          organizationType: user.organizationType,
          organizationName: user.organizationName,
          region: user.region,
          state: user.state,
        } 
      });
    } catch (error) {
      console.error("Login error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          email: user.email, 
          role: user.role,
          organizationType: user.organizationType,
          organizationName: user.organizationName,
          region: user.region,
          state: user.state,
        } 
      });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Dashboard routes - no authentication required
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getSystemMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Get metrics error:", error);
      res.status(500).json({ error: "Failed to get metrics" });
    }
  });

  app.get("/api/dashboard/predictions", async (req, res) => {
    try {
      // Get active predictions for all users
      const predictions = await storage.getActivePredictions();
      res.json(predictions);
    } catch (error) {
      console.error("Get predictions error:", error);
      res.status(500).json({ error: "Failed to get predictions" });
    }
  });

  app.post("/api/dashboard/generate-predictions", async (req, res) => {
    try {
      // Check if GEMINI_API_KEY is available
      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "Gemini API key not configured" });
      }

      // Generate predictions for Maharashtra, India (hardcoded for demo)
      await predictionService.generatePredictions(1, "Maharashtra", "India");
      res.json({ message: "Predictions generated successfully" });
    } catch (error) {
      console.error("Generate predictions error:", error);
      res.status(500).json({ error: error.message || "Failed to generate predictions" });
    }
  });

  app.get("/api/dashboard/alerts", async (req, res) => {
    try {
      // Get recent alerts for all users
      const predictions = await storage.getActivePredictions();
      const alerts = predictions.filter(p => p.riskLevel === "high").map(p => ({
        id: p.id,
        title: `High Risk: ${p.disease.name}`,
        description: `${p.disease.name} outbreak predicted in ${p.region}`,
        type: "high-risk",
        isRead: false,
        createdAt: p.createdAt
      }));
      res.json(alerts);
    } catch (error) {
      console.error("Get alerts error:", error);
      res.status(500).json({ error: "Failed to get alerts" });
    }
  });

  app.get("/api/dashboard/alerts/unread", async (req, res) => {
    try {
      // Get unread alerts for all users
      const predictions = await storage.getActivePredictions();
      const alerts = predictions.filter(p => p.riskLevel === "high").map(p => ({
        id: p.id,
        title: `High Risk: ${p.disease.name}`,
        description: `${p.disease.name} outbreak predicted in ${p.region}`,
        type: "high-risk",
        isRead: false,
        createdAt: p.createdAt
      }));
      res.json(alerts);
    } catch (error) {
      console.error("Get unread alerts error:", error);
      res.status(500).json({ error: "Failed to get unread alerts" });
    }
  });

  app.patch("/api/dashboard/alerts/:id/read", async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      if (isNaN(alertId)) {
        return res.status(400).json({ error: "Invalid alert ID" });
      }
      
      // For demo purposes, just return success
      res.json({ message: "Alert marked as read" });
    } catch (error) {
      console.error("Mark alert as read error:", error);
      res.status(500).json({ error: "Failed to mark alert as read" });
    }
  });

  app.get("/api/dashboard/environmental-data", async (req, res) => {
    try {
      // Get environmental data for Maharashtra (hardcoded for demo)
      const environmentalData = await storage.getLatestEnvironmentalData("Maharashtra");
      res.json(environmentalData);
    } catch (error) {
      console.error("Get environmental data error:", error);
      res.status(500).json({ error: "Failed to get environmental data" });
    }
  });

  app.get("/api/dashboard/diseases", async (req, res) => {
    try {
      const diseases = await storage.getAllDiseases();
      res.json(diseases);
    } catch (error) {
      console.error("Get diseases error:", error);
      res.status(500).json({ error: "Failed to get diseases" });
    }
  });

  app.get("/api/dashboard/medicines/:diseaseId", async (req, res) => {
    try {
      const diseaseId = parseInt(req.params.diseaseId);
      if (isNaN(diseaseId)) {
        return res.status(400).json({ error: "Invalid disease ID" });
      }
      
      const medicines = await storage.getMedicinesByDisease(diseaseId);
      res.json(medicines);
    } catch (error) {
      console.error("Get medicines error:", error);
      res.status(500).json({ error: "Failed to get medicines" });
    }
  });

  // Admin routes - no authentication required
  app.get("/api/admin/users", async (req, res) => {
    try {
      const totalUsers = await storage.getTotalUsers();
      const newRegistrations = await storage.getNewRegistrations(7);
      const activeSessions = await storage.getActiveSessions();
      
      res.json({ 
        totalUsers, 
        newRegistrations, 
        activeSessions 
      });
    } catch (error) {
      console.error("Get admin users error:", error);
      res.status(500).json({ error: "Failed to get user data" });
    }
  });

  app.get("/api/admin/predictions", async (req, res) => {
    try {
      const predictions = await storage.getActivePredictions();
      res.json(predictions);
    } catch (error) {
      console.error("Get admin predictions error:", error);
      res.status(500).json({ error: "Failed to get predictions" });
    }
  });

  app.get("/api/admin/predictions/:region", async (req, res) => {
    try {
      const region = req.params.region;
      const predictions = await storage.getPredictionsByRegion(region);
      res.json(predictions);
    } catch (error) {
      console.error("Get region predictions error:", error);
      res.status(500).json({ error: "Failed to get region predictions" });
    }
  });

  app.post("/api/admin/environmental-data", async (req, res) => {
    try {
      const data = insertEnvironmentalDataSchema.parse(req.body);
      const environmentalData = await storage.createEnvironmentalData(data);
      res.json(environmentalData);
    } catch (error) {
      console.error("Create environmental data error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create environmental data" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || "development",
      version: "1.0.0"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
