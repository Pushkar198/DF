import { 
  users, 
  diseases, 
  medicines, 
  predictions, 
  alerts, 
  environmentalData, 
  diseaseMedicines,
  reports,
  type User, 
  type InsertUser, 
  type Disease, 
  type InsertDisease,
  type Medicine,
  type InsertMedicine,
  type Prediction,
  type InsertPrediction,
  type Alert,
  type InsertAlert,
  type EnvironmentalData,
  type InsertEnvironmentalData,
  type PredictionWithDisease,
  type AlertWithPrediction,
  type DiseaseMedicineWithDetails
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, gte, lte, or, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getUsersByRegion(region: string): Promise<User[]>;
  
  // Disease operations
  getAllDiseases(): Promise<Disease[]>;
  getDiseaseById(id: number): Promise<Disease | undefined>;
  createDisease(disease: InsertDisease): Promise<Disease>;
  getDiseasesByPattern(pattern: string): Promise<Disease[]>;
  
  // Medicine operations
  getAllMedicines(): Promise<Medicine[]>;
  getMedicineById(id: number): Promise<Medicine | undefined>;
  createMedicine(medicine: InsertMedicine): Promise<Medicine>;
  getMedicinesByDisease(diseaseId: number): Promise<DiseaseMedicineWithDetails[]>;
  
  // Prediction operations
  createPrediction(prediction: InsertPrediction & { userId: number }): Promise<Prediction>;
  getPredictionsByUser(userId: number): Promise<PredictionWithDisease[]>;
  getPredictionsByRegion(region: string): Promise<PredictionWithDisease[]>;
  getActivePredictions(): Promise<PredictionWithDisease[]>;
  getPredictionAccuracy(userId?: number): Promise<{ accuracy: number; total: number }>;
  
  // Alert operations
  createAlert(alert: InsertAlert & { userId: number }): Promise<Alert>;
  getAlertsByUser(userId: number): Promise<AlertWithPrediction[]>;
  getUnreadAlerts(userId: number): Promise<AlertWithPrediction[]>;
  markAlertAsRead(id: number): Promise<void>;
  
  // Environmental data operations
  getLatestEnvironmentalData(region: string): Promise<EnvironmentalData | undefined>;
  createEnvironmentalData(data: InsertEnvironmentalData): Promise<EnvironmentalData>;
  getEnvironmentalDataByRegion(region: string, days: number): Promise<EnvironmentalData[]>;
  
  // Admin operations
  getTotalUsers(): Promise<number>;
  getActiveSessions(): Promise<number>;
  getNewRegistrations(days: number): Promise<number>;
  getSystemMetrics(): Promise<{
    totalUsers: number;
    activePredictions: number;
    highRiskAreas: number;
    accuracy: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getUsersByRegion(region: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.region, region));
  }

  async getAllDiseases(): Promise<Disease[]> {
    return await db.select().from(diseases).orderBy(asc(diseases.name));
  }

  async getDiseaseById(id: number): Promise<Disease | undefined> {
    const [disease] = await db.select().from(diseases).where(eq(diseases.id, id));
    return disease || undefined;
  }

  async createDisease(disease: InsertDisease): Promise<Disease> {
    const [newDisease] = await db
      .insert(diseases)
      .values(disease)
      .returning();
    return newDisease;
  }

  async getDiseasesByPattern(pattern: string): Promise<Disease[]> {
    return await db.select().from(diseases).where(eq(diseases.seasonalPattern, pattern));
  }

  async getAllMedicines(): Promise<Medicine[]> {
    return await db.select().from(medicines).orderBy(asc(medicines.name));
  }

  async getMedicineById(id: number): Promise<Medicine | undefined> {
    const [medicine] = await db.select().from(medicines).where(eq(medicines.id, id));
    return medicine || undefined;
  }

  async createMedicine(medicine: InsertMedicine): Promise<Medicine> {
    const [newMedicine] = await db
      .insert(medicines)
      .values(medicine)
      .returning();
    return newMedicine;
  }

  async getMedicinesByDisease(diseaseId: number): Promise<DiseaseMedicineWithDetails[]> {
    return await db
      .select({
        id: diseaseMedicines.id,
        diseaseId: diseaseMedicines.diseaseId,
        medicineId: diseaseMedicines.medicineId,
        priority: diseaseMedicines.priority,
        usage: diseaseMedicines.usage,
        disease: diseases,
        medicine: medicines,
      })
      .from(diseaseMedicines)
      .innerJoin(diseases, eq(diseaseMedicines.diseaseId, diseases.id))
      .innerJoin(medicines, eq(diseaseMedicines.medicineId, medicines.id))
      .where(eq(diseaseMedicines.diseaseId, diseaseId));
  }

  async createPrediction(prediction: InsertPrediction & { userId: number }): Promise<Prediction> {
    const [newPrediction] = await db
      .insert(predictions)
      .values(prediction)
      .returning();
    return newPrediction;
  }

  async getPredictionsByUser(userId: number): Promise<PredictionWithDisease[]> {
    return await db
      .select({
        id: predictions.id,
        userId: predictions.userId,
        diseaseId: predictions.diseaseId,
        region: predictions.region,
        state: predictions.state,
        riskLevel: predictions.riskLevel,
        confidence: predictions.confidence,
        predictedDate: predictions.predictedDate,
        contributingFactors: predictions.contributingFactors,
        geminiResponse: predictions.geminiResponse,
        environmentalData: predictions.environmentalData,
        socialData: predictions.socialData,
        isActive: predictions.isActive,
        createdAt: predictions.createdAt,
        updatedAt: predictions.updatedAt,
        disease: diseases,
        user: users,
      })
      .from(predictions)
      .innerJoin(diseases, eq(predictions.diseaseId, diseases.id))
      .innerJoin(users, eq(predictions.userId, users.id))
      .where(eq(predictions.userId, userId))
      .orderBy(desc(predictions.createdAt));
  }

  async getPredictionsByRegion(region: string): Promise<PredictionWithDisease[]> {
    return await db
      .select({
        id: predictions.id,
        userId: predictions.userId,
        diseaseId: predictions.diseaseId,
        region: predictions.region,
        state: predictions.state,
        riskLevel: predictions.riskLevel,
        confidence: predictions.confidence,
        predictedDate: predictions.predictedDate,
        contributingFactors: predictions.contributingFactors,
        geminiResponse: predictions.geminiResponse,
        environmentalData: predictions.environmentalData,
        socialData: predictions.socialData,
        isActive: predictions.isActive,
        createdAt: predictions.createdAt,
        updatedAt: predictions.updatedAt,
        disease: diseases,
        user: users,
      })
      .from(predictions)
      .innerJoin(diseases, eq(predictions.diseaseId, diseases.id))
      .innerJoin(users, eq(predictions.userId, users.id))
      .where(eq(predictions.region, region))
      .orderBy(desc(predictions.createdAt));
  }

  async getActivePredictions(): Promise<PredictionWithDisease[]> {
    return await db
      .select({
        id: predictions.id,
        userId: predictions.userId,
        diseaseId: predictions.diseaseId,
        region: predictions.region,
        state: predictions.state,
        riskLevel: predictions.riskLevel,
        confidence: predictions.confidence,
        predictedDate: predictions.predictedDate,
        contributingFactors: predictions.contributingFactors,
        geminiResponse: predictions.geminiResponse,
        environmentalData: predictions.environmentalData,
        socialData: predictions.socialData,
        isActive: predictions.isActive,
        createdAt: predictions.createdAt,
        updatedAt: predictions.updatedAt,
        disease: diseases,
        user: users,
      })
      .from(predictions)
      .innerJoin(diseases, eq(predictions.diseaseId, diseases.id))
      .innerJoin(users, eq(predictions.userId, users.id))
      .where(eq(predictions.isActive, true))
      .orderBy(desc(predictions.createdAt));
  }

  async getPredictionAccuracy(userId?: number): Promise<{ accuracy: number; total: number }> {
    const conditions = userId ? [eq(predictions.userId, userId)] : [];
    
    const result = await db
      .select({
        total: sql<number>`count(*)`,
        accurate: sql<number>`count(*) filter (where ${predictions.confidence} >= 80)`,
      })
      .from(predictions)
      .where(and(...conditions));

    const { total, accurate } = result[0];
    return {
      accuracy: total > 0 ? Math.round((accurate / total) * 100) : 0,
      total: total || 0,
    };
  }

  async createAlert(alert: InsertAlert & { userId: number }): Promise<Alert> {
    const [newAlert] = await db
      .insert(alerts)
      .values(alert)
      .returning();
    return newAlert;
  }

  async getAlertsByUser(userId: number): Promise<AlertWithPrediction[]> {
    return await db
      .select({
        id: alerts.id,
        predictionId: alerts.predictionId,
        userId: alerts.userId,
        title: alerts.title,
        message: alerts.message,
        severity: alerts.severity,
        isRead: alerts.isRead,
        isActive: alerts.isActive,
        createdAt: alerts.createdAt,
        prediction: {
          id: predictions.id,
          userId: predictions.userId,
          diseaseId: predictions.diseaseId,
          region: predictions.region,
          state: predictions.state,
          riskLevel: predictions.riskLevel,
          confidence: predictions.confidence,
          predictedDate: predictions.predictedDate,
          contributingFactors: predictions.contributingFactors,
          geminiResponse: predictions.geminiResponse,
          environmentalData: predictions.environmentalData,
          socialData: predictions.socialData,
          isActive: predictions.isActive,
          createdAt: predictions.createdAt,
          updatedAt: predictions.updatedAt,
          disease: diseases,
          user: users,
        },
      })
      .from(alerts)
      .innerJoin(predictions, eq(alerts.predictionId, predictions.id))
      .innerJoin(diseases, eq(predictions.diseaseId, diseases.id))
      .innerJoin(users, eq(predictions.userId, users.id))
      .where(eq(alerts.userId, userId))
      .orderBy(desc(alerts.createdAt));
  }

  async getUnreadAlerts(userId: number): Promise<AlertWithPrediction[]> {
    return await db
      .select({
        id: alerts.id,
        predictionId: alerts.predictionId,
        userId: alerts.userId,
        title: alerts.title,
        message: alerts.message,
        severity: alerts.severity,
        isRead: alerts.isRead,
        isActive: alerts.isActive,
        createdAt: alerts.createdAt,
        prediction: {
          id: predictions.id,
          userId: predictions.userId,
          diseaseId: predictions.diseaseId,
          region: predictions.region,
          state: predictions.state,
          riskLevel: predictions.riskLevel,
          confidence: predictions.confidence,
          predictedDate: predictions.predictedDate,
          contributingFactors: predictions.contributingFactors,
          geminiResponse: predictions.geminiResponse,
          environmentalData: predictions.environmentalData,
          socialData: predictions.socialData,
          isActive: predictions.isActive,
          createdAt: predictions.createdAt,
          updatedAt: predictions.updatedAt,
          disease: diseases,
          user: users,
        },
      })
      .from(alerts)
      .innerJoin(predictions, eq(alerts.predictionId, predictions.id))
      .innerJoin(diseases, eq(predictions.diseaseId, diseases.id))
      .innerJoin(users, eq(predictions.userId, users.id))
      .where(and(eq(alerts.userId, userId), eq(alerts.isRead, false)))
      .orderBy(desc(alerts.createdAt));
  }

  async markAlertAsRead(id: number): Promise<void> {
    await db
      .update(alerts)
      .set({ isRead: true })
      .where(eq(alerts.id, id));
  }

  async getLatestEnvironmentalData(region: string): Promise<EnvironmentalData | undefined> {
    const [data] = await db
      .select()
      .from(environmentalData)
      .where(eq(environmentalData.region, region))
      .orderBy(desc(environmentalData.recordedAt))
      .limit(1);
    return data || undefined;
  }

  async createEnvironmentalData(data: InsertEnvironmentalData): Promise<EnvironmentalData> {
    const [newData] = await db
      .insert(environmentalData)
      .values(data)
      .returning();
    return newData;
  }

  async getEnvironmentalDataByRegion(region: string, days: number): Promise<EnvironmentalData[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    return await db
      .select()
      .from(environmentalData)
      .where(
        and(
          eq(environmentalData.region, region),
          gte(environmentalData.recordedAt, startDate)
        )
      )
      .orderBy(desc(environmentalData.recordedAt));
  }

  async getTotalUsers(): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);
    return result.count;
  }

  async getActiveSessions(): Promise<number> {
    // For now, return a placeholder - implement session tracking later
    return 0;
  }

  async getNewRegistrations(days: number): Promise<number> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(gte(users.createdAt, startDate));
    return result.count;
  }

  async getSystemMetrics(): Promise<{
    totalUsers: number;
    activePredictions: number;
    highRiskAreas: number;
    accuracy: number;
  }> {
    const [totalUsersResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);
    
    const [activePredictionsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(predictions)
      .where(eq(predictions.isActive, true));
    
    const [highRiskAreasResult] = await db
      .select({ count: sql<number>`count(distinct ${predictions.region})` })
      .from(predictions)
      .where(and(eq(predictions.isActive, true), eq(predictions.riskLevel, 'high')));
    
    const accuracyResult = await this.getPredictionAccuracy();
    
    return {
      totalUsers: totalUsersResult.count,
      activePredictions: activePredictionsResult.count,
      highRiskAreas: highRiskAreasResult.count,
      accuracy: accuracyResult.accuracy,
    };
  }
}

export const storage = new DatabaseStorage();
