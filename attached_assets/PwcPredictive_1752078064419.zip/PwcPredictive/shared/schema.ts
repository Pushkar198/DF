import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  email: varchar("email", { length: 100 }).notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // 'user' or 'admin'
  organizationType: text("organization_type").notNull(), // 'chemist', 'pharma', 'health_dept'
  organizationName: text("organization_name").notNull(),
  region: text("region").notNull(),
  state: text("state").notNull(),
  country: text("country").notNull().default("India"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const diseases = pgTable("diseases", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  symptoms: text("symptoms").array(),
  riskFactors: text("risk_factors").array(),
  seasonalPattern: text("seasonal_pattern"), // 'winter', 'monsoon', 'summer'
  severity: text("severity").notNull(), // 'low', 'medium', 'high'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const medicines = pgTable("medicines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  genericName: text("generic_name"),
  category: text("category").notNull(), // 'antibiotic', 'antipyretic', 'antiviral', etc.
  dosage: text("dosage"),
  sideEffects: text("side_effects").array(),
  contraindications: text("contraindications").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const diseaseMedicines = pgTable("disease_medicines", {
  id: serial("id").primaryKey(),
  diseaseId: integer("disease_id").references(() => diseases.id).notNull(),
  medicineId: integer("medicine_id").references(() => medicines.id).notNull(),
  priority: text("priority").notNull().default("medium"), // 'high', 'medium', 'low'
  usage: text("usage"), // 'prevention', 'treatment', 'symptom_relief'
});

export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  diseaseId: integer("disease_id").references(() => diseases.id).notNull(),
  region: text("region").notNull(),
  state: text("state").notNull(),
  riskLevel: text("risk_level").notNull(), // 'low', 'medium', 'high'
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  predictedDate: timestamp("predicted_date").notNull(),
  contributingFactors: jsonb("contributing_factors").notNull(),
  geminiResponse: jsonb("gemini_response").notNull(),
  environmentalData: jsonb("environmental_data"),
  socialData: jsonb("social_data"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  predictionId: integer("prediction_id").references(() => predictions.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  severity: text("severity").notNull(), // 'low', 'medium', 'high', 'critical'
  isRead: boolean("is_read").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const environmentalData = pgTable("environmental_data", {
  id: serial("id").primaryKey(),
  region: text("region").notNull(),
  state: text("state").notNull(),
  temperature: decimal("temperature", { precision: 5, scale: 2 }),
  humidity: decimal("humidity", { precision: 5, scale: 2 }),
  rainfall: decimal("rainfall", { precision: 8, scale: 2 }),
  windSpeed: decimal("wind_speed", { precision: 5, scale: 2 }),
  airQuality: text("air_quality"),
  floodAlert: boolean("flood_alert").default(false),
  heatwaveAlert: boolean("heatwave_alert").default(false),
  dataSource: text("data_source").notNull(),
  recordedAt: timestamp("recorded_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  type: text("type").notNull(), // 'prediction', 'historical', 'accuracy', 'regional'
  region: text("region").notNull(),
  dateRange: jsonb("date_range").notNull(),
  data: jsonb("data").notNull(),
  format: text("format").notNull().default("json"), // 'json', 'pdf', 'csv'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  predictions: many(predictions),
  alerts: many(alerts),
  reports: many(reports),
}));

export const diseasesRelations = relations(diseases, ({ many }) => ({
  predictions: many(predictions),
  diseaseMedicines: many(diseaseMedicines),
}));

export const medicinesRelations = relations(medicines, ({ many }) => ({
  diseaseMedicines: many(diseaseMedicines),
}));

export const diseaseMedicinesRelations = relations(diseaseMedicines, ({ one }) => ({
  disease: one(diseases, {
    fields: [diseaseMedicines.diseaseId],
    references: [diseases.id],
  }),
  medicine: one(medicines, {
    fields: [diseaseMedicines.medicineId],
    references: [medicines.id],
  }),
}));

export const predictionsRelations = relations(predictions, ({ one, many }) => ({
  user: one(users, {
    fields: [predictions.userId],
    references: [users.id],
  }),
  disease: one(diseases, {
    fields: [predictions.diseaseId],
    references: [diseases.id],
  }),
  alerts: many(alerts),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  user: one(users, {
    fields: [alerts.userId],
    references: [users.id],
  }),
  prediction: one(predictions, {
    fields: [alerts.predictionId],
    references: [predictions.id],
  }),
}));

export const reportsRelations = relations(reports, ({ one }) => ({
  user: one(users, {
    fields: [reports.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  organizationType: true,
  organizationName: true,
  region: true,
  state: true,
  country: true,
});

export const insertDiseaseSchema = createInsertSchema(diseases).pick({
  name: true,
  description: true,
  symptoms: true,
  riskFactors: true,
  seasonalPattern: true,
  severity: true,
});

export const insertMedicineSchema = createInsertSchema(medicines).pick({
  name: true,
  genericName: true,
  category: true,
  dosage: true,
  sideEffects: true,
  contraindications: true,
});

export const insertPredictionSchema = createInsertSchema(predictions).pick({
  diseaseId: true,
  region: true,
  state: true,
  riskLevel: true,
  confidence: true,
  predictedDate: true,
  contributingFactors: true,
  geminiResponse: true,
  environmentalData: true,
  socialData: true,
});

export const insertAlertSchema = createInsertSchema(alerts).pick({
  predictionId: true,
  title: true,
  message: true,
  severity: true,
});

export const insertEnvironmentalDataSchema = createInsertSchema(environmentalData).pick({
  region: true,
  state: true,
  temperature: true,
  humidity: true,
  rainfall: true,
  windSpeed: true,
  airQuality: true,
  floodAlert: true,
  heatwaveAlert: true,
  dataSource: true,
  recordedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Disease = typeof diseases.$inferSelect;
export type InsertDisease = z.infer<typeof insertDiseaseSchema>;
export type Medicine = typeof medicines.$inferSelect;
export type InsertMedicine = z.infer<typeof insertMedicineSchema>;
export type DiseaseMedicine = typeof diseaseMedicines.$inferSelect;
export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type EnvironmentalData = typeof environmentalData.$inferSelect;
export type InsertEnvironmentalData = z.infer<typeof insertEnvironmentalDataSchema>;
export type Report = typeof reports.$inferSelect;

// Extended types with relations
export type PredictionWithDisease = Prediction & {
  disease: Disease;
  user: User;
};

export type AlertWithPrediction = Alert & {
  prediction: PredictionWithDisease;
};

export type DiseaseMedicineWithDetails = DiseaseMedicine & {
  disease: Disease;
  medicine: Medicine;
};
