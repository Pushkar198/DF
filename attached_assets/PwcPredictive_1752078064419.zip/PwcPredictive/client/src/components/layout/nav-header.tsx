import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Heart, Settings } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

export default function NavHeader() {
  const { data: unreadAlerts = [] } = useQuery({
    queryKey: ["/api/dashboard/alerts/unread"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  return (
    <nav className="pwc-dark-blue text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Heart className="h-8 w-8 mr-3" />
              <span className="text-xl font-bold">PredictMed Insight</span>
              <Badge className="ml-2 pwc-orange text-white">by PwC</Badge>
            </div>
          </div>

          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/" className="px-3 py-2 rounded-md text-sm font-medium pwc-blue text-white">
                Dashboard
              </Link>
              <Link href="/predictions" className="px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-pwc-blue">
                Predictions
              </Link>
              <Link href="/analytics" className="px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-pwc-blue">
                Analytics
              </Link>
              <Link href="/reports" className="px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-pwc-blue">
                Reports
              </Link>
              <Link href="/admin" className="px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-pwc-blue">
                Admin
              </Link>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <Button variant="ghost" size="sm" className="p-2 rounded-full text-gray-300 hover:text-white hover:bg-pwc-blue">
                <Bell className="h-5 w-5" />
                {unreadAlerts.length > 0 && (
                  <span className="absolute -top-1 -right-1 block h-4 w-4 rounded-full pwc-orange text-xs text-white flex items-center justify-center">
                    {unreadAlerts.length}
                  </span>
                )}
              </Button>
            </div>

            <Button variant="ghost" className="flex items-center space-x-2 text-gray-300 hover:text-white hover:bg-pwc-blue">
              <span className="text-sm">Healthcare Analytics</span>
              <div className="w-8 h-8 pwc-blue rounded-full flex items-center justify-center">
                <span className="text-sm font-medium">HA</span>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
