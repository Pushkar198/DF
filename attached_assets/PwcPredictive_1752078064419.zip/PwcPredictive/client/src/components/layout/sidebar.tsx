import { cn } from "@/lib/utils";
import { 
  Activity, 
  CloudSun, 
  FileText, 
  MapPin, 
  PillBottle, 
  Settings, 
  TrendingUp 
} from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();

  const navigation = [
    {
      name: "Dashboard",
      href: "/",
      icon: Activity,
      current: location === "/",
    },
    {
      name: "Disease Predictions",
      href: "/predictions",
      icon: TrendingUp,
      current: location === "/predictions",
    },
    {
      name: "Medicine Recommendations",
      href: "/medicines",
      icon: PillBottle,
      current: location === "/medicines",
    },
    {
      name: "Environmental Data",
      href: "/environmental",
      icon: CloudSun,
      current: location === "/environmental",
    },
    {
      name: "Reports",
      href: "/reports",
      icon: FileText,
      current: location === "/reports",
    },
    {
      name: "Settings",
      href: "/settings",
      icon: Settings,
      current: location === "/settings",
    },
  ];

  return (
    <aside className="w-64 bg-white shadow-sm min-h-screen">
      <div className="p-6">
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider">
            Region
          </h3>
          <div className="mt-2 flex items-center space-x-2">
            <MapPin className="h-4 w-4 text-pwc-blue" />
            <span className="text-sm font-medium">Maharashtra, India</span>
          </div>
        </div>

        <nav className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  item.current
                    ? "bg-pwc-light-blue text-pwc-dark-blue"
                    : "text-gray-700 hover:bg-gray-50",
                  "group flex items-center px-3 py-2 text-sm font-medium rounded-md"
                )}
              >
                <Icon
                  className={cn(
                    item.current
                      ? "text-pwc-blue"
                      : "text-gray-400 group-hover:text-gray-500",
                    "mr-3 h-5 w-5"
                  )}
                />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}
