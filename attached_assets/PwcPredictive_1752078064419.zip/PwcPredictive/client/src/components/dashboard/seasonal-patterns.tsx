import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Snowflake, CloudRain, Sun } from "lucide-react";

export default function SeasonalPatterns() {
  const seasons = [
    {
      name: "Winter (Dec-Feb)",
      icon: Snowflake,
      color: "blue",
      diseases: ["Flu", "Pneumonia", "RSV"],
      bgColor: "bg-blue-50",
      textColor: "text-blue-800",
      iconColor: "text-blue-500",
    },
    {
      name: "Monsoon (Jun-Sep)",
      icon: CloudRain,
      color: "green",
      diseases: ["Dengue", "Malaria", "Cholera"],
      bgColor: "bg-green-50",
      textColor: "text-green-800",
      iconColor: "text-green-500",
    },
    {
      name: "Summer (Mar-May)",
      icon: Sun,
      color: "yellow",
      diseases: ["Typhoid", "Heatstroke", "Chickenpox"],
      bgColor: "bg-yellow-50",
      textColor: "text-yellow-800",
      iconColor: "text-yellow-500",
    },
  ];

  return (
    <Card className="shadow-sm mt-8">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900">Seasonal Disease Patterns</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {seasons.map((season) => {
            const Icon = season.icon;
            return (
              <div key={season.name} className={`text-center p-6 ${season.bgColor} rounded-lg`}>
                <Icon className={`h-8 w-8 mx-auto mb-3 ${season.iconColor}`} />
                <h3 className={`font-medium ${season.textColor} mb-2`}>{season.name}</h3>
                <p className="text-sm text-gray-600">
                  {season.diseases.join(", ")}
                </p>
              </div>
            );
          })}
        </div>
        
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-2">Key Insights</h4>
          <ul className="text-sm text-gray-700 space-y-1">
            <li>• Monsoon season shows highest disease outbreak potential</li>
            <li>• Vector-borne diseases peak during June-September</li>
            <li>• Respiratory illnesses are most common in winter months</li>
            <li>• Summer heat-related conditions require immediate attention</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
