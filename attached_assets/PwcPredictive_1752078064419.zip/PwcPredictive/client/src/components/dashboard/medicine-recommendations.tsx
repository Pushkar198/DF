import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { CheckCircle, AlertTriangle, Clock } from "lucide-react";

export default function MedicineRecommendations() {
  const { data: predictions = [] } = useQuery({
    queryKey: ["/api/dashboard/predictions"],
  });

  const { data: diseases = [] } = useQuery({
    queryKey: ["/api/dashboard/diseases"],
  });

  const [selectedDiseaseId, setSelectedDiseaseId] = useState<number | null>(null);

  const { data: medicines = [] } = useQuery({
    queryKey: ["/api/dashboard/medicines", selectedDiseaseId],
    enabled: !!selectedDiseaseId,
  });

  // Get high-risk predictions for medicine recommendations
  const highRiskPredictions = predictions
    .filter((p: any) => p.riskLevel === "high")
    .slice(0, 2);

  const getStatusBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge className="bg-green-100 text-green-800 text-xs">Stock Up</Badge>;
      case "medium":
        return <Badge className="bg-yellow-100 text-yellow-800 text-xs">Monitor</Badge>;
      case "low":
        return <Badge className="bg-gray-100 text-gray-800 text-xs">Normal</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 text-xs">Normal</Badge>;
    }
  };

  const getStatusIcon = (priority: string) => {
    switch (priority) {
      case "high":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "medium":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "low":
        return <AlertTriangle className="h-4 w-4 text-gray-500" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  // Mock medicine data based on common diseases
  const mockMedicineData = {
    "Dengue": [
      { name: "Paracetamol", priority: "high", usage: "treatment" },
      { name: "IV Fluids", priority: "high", usage: "treatment" },
      { name: "Platelet Boosters", priority: "medium", usage: "treatment" },
    ],
    "Malaria": [
      { name: "Artemether", priority: "medium", usage: "treatment" },
      { name: "Quinine", priority: "low", usage: "treatment" },
      { name: "Chloroquine", priority: "low", usage: "prevention" },
    ],
    "Seasonal Flu": [
      { name: "Oseltamivir", priority: "medium", usage: "treatment" },
      { name: "Paracetamol", priority: "high", usage: "symptom_relief" },
      { name: "Cough Syrup", priority: "low", usage: "symptom_relief" },
    ],
  };

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900">Medicine Recommendations</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {highRiskPredictions.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <CheckCircle className="h-8 w-8 mx-auto mb-2" />
              <p>No high-risk predictions</p>
              <p className="text-sm">Medicine recommendations will appear here</p>
            </div>
          ) : (
            highRiskPredictions.map((prediction: any) => {
              const diseaseName = prediction.disease.name;
              const recommendedMedicines = mockMedicineData[diseaseName as keyof typeof mockMedicineData] || [];
              
              return (
                <div key={prediction.id} className="border rounded-lg p-4">
                  <h3 className="font-medium text-gray-900 mb-3">
                    {diseaseName} Prevention & Treatment
                  </h3>
                  <div className="space-y-2">
                    {recommendedMedicines.map((medicine, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(medicine.priority)}
                          <span className="text-sm">{medicine.name}</span>
                        </div>
                        {getStatusBadge(medicine.priority)}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Generic recommendations */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">General Recommendations</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Maintain adequate stock of antipyretics</li>
            <li>• Ensure availability of ORS packets</li>
            <li>• Monitor antibiotic inventory levels</li>
            <li>• Stock up on IV fluids during monsoon</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
