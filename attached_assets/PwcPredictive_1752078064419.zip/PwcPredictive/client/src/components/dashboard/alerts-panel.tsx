import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { AlertTriangle, CheckCircle, Clock } from "lucide-react";

export default function AlertsPanel() {
  const queryClient = useQueryClient();
  
  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["/api/dashboard/alerts"],
    refetchInterval: 30000,
  });

  const markAsReadMutation = useMutation({
    mutationFn: (alertId: number) => apiRequest("PATCH", `/api/dashboard/alerts/${alertId}/read`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/alerts/unread"] });
    },
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "border-red-500 text-red-800";
      case "medium":
        return "border-yellow-500 text-yellow-800";
      case "low":
        return "border-blue-500 text-blue-800";
      default:
        return "border-gray-500 text-gray-800";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high":
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case "medium":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "low":
        return <CheckCircle className="h-4 w-4 text-blue-500" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gray-900">Current Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const activeAlerts = alerts.filter((alert: any) => alert.isActive).slice(0, 3);

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900">Current Alerts</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activeAlerts.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <CheckCircle className="h-8 w-8 mx-auto mb-2" />
              <p>No active alerts</p>
            </div>
          ) : (
            activeAlerts.map((alert: any) => (
              <div
                key={alert.id}
                className={`border-l-4 pl-4 py-3 ${getSeverityColor(alert.severity)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {getSeverityIcon(alert.severity)}
                      <h3 className="font-medium">{alert.title}</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-1">{alert.message}</p>
                    <p className="text-xs text-gray-500">
                      {alert.prediction?.region}, {alert.prediction?.state}
                    </p>
                  </div>
                  {!alert.isRead && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markAsReadMutation.mutate(alert.id)}
                      disabled={markAsReadMutation.isPending}
                    >
                      Mark as read
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
        {activeAlerts.length > 0 && (
          <Button 
            variant="outline" 
            className="w-full mt-4 text-pwc-blue hover:bg-pwc-light-blue"
          >
            View All Alerts
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
