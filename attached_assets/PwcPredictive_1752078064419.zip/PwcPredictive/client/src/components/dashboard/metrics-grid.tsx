import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TriangleAlert, Target, Database } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function MetricsGrid() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    refetchInterval: 60000, // Refetch every minute
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const metricItems = [
    {
      title: "Active Predictions",
      value: metrics?.activePredictions || 0,
      icon: Brain,
      iconBg: "bg-pwc-light-blue",
      iconColor: "text-pwc-blue",
      change: "+2.5%",
      changeColor: "text-green-600",
      changeLabel: "vs last week",
    },
    {
      title: "High Risk Areas",
      value: metrics?.highRiskAreas || 0,
      icon: TriangleAlert,
      iconBg: "bg-red-50",
      iconColor: "text-red-500",
      change: "+1",
      changeColor: "text-red-600",
      changeLabel: "new alert",
    },
    {
      title: "Prediction Accuracy",
      value: `${metrics?.accuracy || 0}%`,
      icon: Target,
      iconBg: "bg-green-50",
      iconColor: "text-green-500",
      change: "+1.2%",
      changeColor: "text-green-600",
      changeLabel: "improved",
    },
    {
      title: "Data Sources",
      value: 28,
      icon: Database,
      iconBg: "bg-blue-50",
      iconColor: "text-blue-500",
      change: "Active",
      changeColor: "text-blue-600",
      changeLabel: "all systems",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricItems.map((item) => {
        const Icon = item.icon;
        return (
          <Card key={item.title} className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{item.title}</p>
                  <p className="text-3xl font-bold text-gray-900">{item.value}</p>
                </div>
                <div className={`p-3 ${item.iconBg} rounded-full`}>
                  <Icon className={`h-6 w-6 ${item.iconColor}`} />
                </div>
              </div>
              <div className="mt-2 flex items-center text-sm">
                <span className={`font-medium ${item.changeColor}`}>
                  {item.change}
                </span>
                <span className="text-gray-500 ml-1">{item.changeLabel}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
