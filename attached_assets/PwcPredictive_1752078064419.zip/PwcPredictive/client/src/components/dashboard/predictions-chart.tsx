import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

export default function PredictionsChart() {
  const [timeRange, setTimeRange] = useState("30");
  
  const { data: predictions = [] } = useQuery({
    queryKey: ["/api/dashboard/predictions"],
    refetchInterval: 30000,
  });

  // Transform predictions data for chart
  const chartData = predictions.slice(0, 4).map((prediction: any, index: number) => ({
    week: `Week ${index + 1}`,
    dengue: prediction.disease.name === "Dengue" ? parseInt(prediction.confidence) : Math.random() * 100,
    malaria: prediction.disease.name === "Malaria" ? parseInt(prediction.confidence) : Math.random() * 100,
    flu: prediction.disease.name === "Seasonal Flu" ? parseInt(prediction.confidence) : Math.random() * 100,
  }));

  // Default data if no predictions
  const defaultData = [
    { week: "Week 1", dengue: 30, malaria: 20, flu: 10 },
    { week: "Week 2", dengue: 45, malaria: 25, flu: 15 },
    { week: "Week 3", dengue: 75, malaria: 40, flu: 20 },
    { week: "Week 4", dengue: 85, malaria: 50, flu: 25 },
  ];

  const displayData = chartData.length > 0 ? chartData : defaultData;

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-semibold text-gray-900">
            Disease Predictions - Next 30 Days
          </CardTitle>
          <div className="flex space-x-2">
            <Button
              variant={timeRange === "30" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange("30")}
              className={timeRange === "30" ? "pwc-blue" : ""}
            >
              30 Days
            </Button>
            <Button
              variant={timeRange === "90" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange("90")}
              className={timeRange === "90" ? "pwc-blue" : ""}
            >
              90 Days
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={displayData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis 
                domain={[0, 100]}
                tickFormatter={(value) => `${value}%`}
              />
              <Tooltip 
                formatter={(value) => [`${value}%`, 'Risk Level']}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="dengue" 
                stroke="hsl(16, 100%, 60%)" 
                strokeWidth={2}
                name="Dengue Risk"
              />
              <Line 
                type="monotone" 
                dataKey="malaria" 
                stroke="hsl(36, 100%, 57%)" 
                strokeWidth={2}
                name="Malaria Risk"
              />
              <Line 
                type="monotone" 
                dataKey="flu" 
                stroke="hsl(207, 100%, 40%)" 
                strokeWidth={2}
                name="Seasonal Flu"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
