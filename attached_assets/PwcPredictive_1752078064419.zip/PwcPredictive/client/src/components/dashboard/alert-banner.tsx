import { useState } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function AlertBanner() {
  const [dismissed, setDismissed] = useState(false);
  
  const { data: alerts = [] } = useQuery({
    queryKey: ["/api/dashboard/alerts/unread"],
    refetchInterval: 30000,
  });

  const highPriorityAlert = alerts.find((alert: any) => alert.severity === "high");

  if (dismissed || !highPriorityAlert) {
    return null;
  }

  return (
    <Alert className="bg-pwc-orange-10 border-pwc-orange mb-6">
      <div className="flex items-center">
        <AlertTriangle className="h-4 w-4 text-pwc-orange mr-3" />
        <div className="flex-1">
          <h3 className="text-sm font-medium text-pwc-orange">
            {highPriorityAlert.title}
          </h3>
          <AlertDescription className="text-sm text-gray-700 mt-1">
            {highPriorityAlert.message}
          </AlertDescription>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setDismissed(true)}
          className="text-pwc-orange hover:text-orange-700"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </Alert>
  );
}
