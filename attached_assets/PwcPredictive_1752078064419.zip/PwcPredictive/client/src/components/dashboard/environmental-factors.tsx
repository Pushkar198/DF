import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CloudRain, Thermometer, Droplets, Wind } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function EnvironmentalFactors() {
  const { data: environmentalData, isLoading } = useQuery({
    queryKey: ["/api/dashboard/environmental-data"],
    refetchInterval: 300000, // Refetch every 5 minutes
  });

  if (isLoading) {
    return (
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gray-900">Environmental Factors</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-12 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const factors = [
    {
      name: "Rainfall",
      value: environmentalData?.rainfall ? `${environmentalData.rainfall}mm` : "N/A",
      status: "Above average",
      change: "+45%",
      icon: CloudRain,
      color: "text-blue-500",
    },
    {
      name: "Temperature",
      value: environmentalData?.temperature ? `${environmentalData.temperature}°C` : "N/A",
      status: "Average",
      change: "High",
      icon: Thermometer,
      color: "text-orange-500",
    },
    {
      name: "Humidity",
      value: environmentalData?.humidity ? `${environmentalData.humidity}%` : "N/A",
      status: "Elevated",
      change: "Elevated",
      icon: Droplets,
      color: "text-cyan-500",
    },
    {
      name: "Wind Speed",
      value: environmentalData?.windSpeed ? `${environmentalData.windSpeed} km/h` : "N/A",
      status: "Normal",
      change: "Normal",
      icon: Wind,
      color: "text-gray-500",
    },
  ];

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900">Environmental Factors</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {factors.map((factor) => {
            const Icon = factor.icon;
            return (
              <div key={factor.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex items-center space-x-3">
                  <Icon className={`h-5 w-5 ${factor.color}`} />
                  <div>
                    <p className="font-medium">{factor.name}</p>
                    <p className="text-sm text-gray-600">{factor.value}</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-xs">
                  {factor.change}
                </Badge>
              </div>
            );
          })}
        </div>
        
        {/* Alert indicators */}
        <div className="mt-4 space-y-2">
          {environmentalData?.floodAlert && (
            <div className="flex items-center space-x-2 text-red-600">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <span className="text-sm">Flood Alert Active</span>
            </div>
          )}
          {environmentalData?.heatwaveAlert && (
            <div className="flex items-center space-x-2 text-orange-600">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span className="text-sm">Heatwave Alert Active</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
