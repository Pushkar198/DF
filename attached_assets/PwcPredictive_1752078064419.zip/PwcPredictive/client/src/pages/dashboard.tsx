import NavHeader from "@/components/layout/nav-header";
import Sidebar from "@/components/layout/sidebar";
import AlertBanner from "@/components/dashboard/alert-banner";
import MetricsGrid from "@/components/dashboard/metrics-grid";
import PredictionsChart from "@/components/dashboard/predictions-chart";
import AlertsPanel from "@/components/dashboard/alerts-panel";
import EnvironmentalFactors from "@/components/dashboard/environmental-factors";
import MedicineRecommendations from "@/components/dashboard/medicine-recommendations";
import SeasonalPatterns from "@/components/dashboard/seasonal-patterns";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Disease Prediction Dashboard</h1>
            <p className="mt-2 text-gray-600">
              AI-powered disease outbreak forecasting for Maharashtra, India
            </p>
          </div>

          <AlertBanner />
          
          <MetricsGrid />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <PredictionsChart />
            </div>
            <div>
              <AlertsPanel />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            <EnvironmentalFactors />
            <MedicineRecommendations />
          </div>

          <SeasonalPatterns />
        </main>
      </div>
    </div>
  );
}
