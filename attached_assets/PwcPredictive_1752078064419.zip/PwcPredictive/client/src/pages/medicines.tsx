import { useQuery } from "@tanstack/react-query";
import NavHeader from "@/components/layout/nav-header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PillBottle, Search, Filter, AlertCircle, Pill } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function MedicinesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDisease, setSelectedDisease] = useState<number | null>(null);

  const { data: diseases = [] } = useQuery({
    queryKey: ["/api/dashboard/diseases"],
  });

  const { data: medicines = [] } = useQuery({
    queryKey: ["/api/dashboard/medicines", selectedDisease],
    enabled: !!selectedDisease,
  });

  const filteredDiseases = diseases.filter((disease: any) =>
    disease.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <PillBottle className="h-8 w-8 text-pwc-blue" />
              Medicine Recommendations
            </h1>
            <p className="mt-2 text-gray-600">
              AI-powered medicine recommendations based on disease predictions
            </p>
          </div>

          <div className="mb-6 flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search diseases..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filter
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Diseases List */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Select Disease</h2>
              <div className="grid gap-3">
                {filteredDiseases.map((disease: any) => (
                  <Card 
                    key={disease.id} 
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedDisease === disease.id ? 'ring-2 ring-pwc-blue' : ''
                    }`}
                    onClick={() => setSelectedDisease(disease.id)}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center justify-between">
                        {disease.name}
                        <Badge variant={disease.severity === 'high' ? 'destructive' : 'secondary'}>
                          {disease.severity}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-3">{disease.description}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <AlertCircle className="h-3 w-3" />
                        <span>Seasonal: {disease.seasonalPattern}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Medicine Recommendations */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Medicine Recommendations</h2>
              
              {!selectedDisease ? (
                <div className="text-center py-12">
                  <Pill className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Select a disease to view medicine recommendations</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Mock medicine recommendations based on selected disease */}
                  {selectedDisease === 1 && ( // Dengue
                    <>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Paracetamol</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 mb-2">
                            Primary fever reducer and pain reliever for dengue management
                          </p>
                          <div className="flex gap-2 mb-3">
                            <Badge variant="outline">Fever Control</Badge>
                            <Badge variant="outline">Pain Relief</Badge>
                          </div>
                          <div className="text-sm">
                            <p><strong>Dosage:</strong> 500mg every 4-6 hours</p>
                            <p><strong>Duration:</strong> As needed for fever</p>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">ORS (Oral Rehydration Solution)</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 mb-2">
                            Essential for maintaining hydration during dengue fever
                          </p>
                          <div className="flex gap-2 mb-3">
                            <Badge variant="outline">Hydration</Badge>
                            <Badge variant="outline">Electrolyte Balance</Badge>
                          </div>
                          <div className="text-sm">
                            <p><strong>Dosage:</strong> 200-400ml every 4 hours</p>
                            <p><strong>Duration:</strong> Throughout fever period</p>
                          </div>
                        </CardContent>
                      </Card>
                    </>
                  )}
                  
                  {selectedDisease === 2 && ( // Malaria
                    <>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Artemether</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 mb-2">
                            Anti-malarial medication for treating malaria infections
                          </p>
                          <div className="flex gap-2 mb-3">
                            <Badge variant="outline">Anti-malarial</Badge>
                            <Badge variant="outline">Primary Treatment</Badge>
                          </div>
                          <div className="text-sm">
                            <p><strong>Dosage:</strong> As per body weight</p>
                            <p><strong>Duration:</strong> 3-7 days</p>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Doxycycline</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 mb-2">
                            Antibiotic used for malaria prevention and treatment
                          </p>
                          <div className="flex gap-2 mb-3">
                            <Badge variant="outline">Prevention</Badge>
                            <Badge variant="outline">Treatment</Badge>
                          </div>
                          <div className="text-sm">
                            <p><strong>Dosage:</strong> 100mg daily</p>
                            <p><strong>Duration:</strong> As prescribed</p>
                          </div>
                        </CardContent>
                      </Card>
                    </>
                  )}
                  
                  {selectedDisease === 3 && ( // Seasonal Flu
                    <>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Oseltamivir</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 mb-2">
                            Antiviral medication for treating seasonal flu
                          </p>
                          <div className="flex gap-2 mb-3">
                            <Badge variant="outline">Antiviral</Badge>
                            <Badge variant="outline">Symptom Relief</Badge>
                          </div>
                          <div className="text-sm">
                            <p><strong>Dosage:</strong> 75mg twice daily</p>
                            <p><strong>Duration:</strong> 5 days</p>
                          </div>
                        </CardContent>
                      </Card>
                    </>
                  )}
                  
                  {selectedDisease > 3 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">General Recommendations</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-2">
                          Medicine recommendations will be generated based on AI analysis
                        </p>
                        <div className="flex gap-2 mb-3">
                          <Badge variant="outline">AI Generated</Badge>
                          <Badge variant="outline">Personalized</Badge>
                        </div>
                        <div className="text-sm">
                          <p><strong>Note:</strong> Consult healthcare provider for specific recommendations</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}