import { useQuery } from "@tanstack/react-query";
import NavHeader from "@/components/layout/nav-header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CloudSun, 
  Thermometer, 
  Droplets, 
  Wind, 
  Eye, 
  AlertTriangle, 
  Zap,
  TrendingUp,
  Calendar
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function EnvironmentalPage() {
  const { data: environmentalData, isLoading } = useQuery({
    queryKey: ["/api/dashboard/environmental-data"],
    refetchInterval: 300000, // 5 minutes
  });

  const getAirQualityColor = (quality: string) => {
    switch (quality?.toLowerCase()) {
      case "good":
        return "bg-green-500 text-white";
      case "moderate":
        return "bg-yellow-500 text-white";
      case "poor":
        return "bg-red-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getTemperatureColor = (temp: number) => {
    if (temp > 35) return "text-red-600";
    if (temp > 30) return "text-orange-600";
    if (temp > 25) return "text-yellow-600";
    return "text-blue-600";
  };

  const getHumidityColor = (humidity: number) => {
    if (humidity > 80) return "text-blue-600";
    if (humidity > 60) return "text-cyan-600";
    return "text-gray-600";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavHeader />
        <div className="flex">
          <Sidebar />
          <main className="flex-1 p-8">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-32 bg-gray-200 rounded"></div>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <CloudSun className="h-8 w-8 text-pwc-blue" />
              Environmental Monitoring
            </h1>
            <p className="mt-2 text-gray-600">
              Real-time environmental data affecting disease patterns in Maharashtra, India
            </p>
          </div>

          {environmentalData && (
            <>
              {/* Main Environmental Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Thermometer className="h-4 w-4" />
                      Temperature
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900">
                      <span className={getTemperatureColor(parseFloat(environmentalData.temperature))}>
                        {environmentalData.temperature}°C
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Last updated: {new Date(environmentalData.recordedAt).toLocaleString()}
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Droplets className="h-4 w-4" />
                      Humidity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900">
                      <span className={getHumidityColor(parseFloat(environmentalData.humidity))}>
                        {environmentalData.humidity}%
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Relative humidity level
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Wind className="h-4 w-4" />
                      Wind Speed
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900">
                      {environmentalData.windSpeed} km/h
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Current wind conditions
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Air Quality
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Badge className={cn("text-xs", getAirQualityColor(environmentalData.airQuality))}>
                      {environmentalData.airQuality?.toUpperCase()}
                    </Badge>
                    <div className="text-xs text-gray-500 mt-2">
                      Air quality index
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Rainfall and Alerts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Droplets className="h-5 w-5 text-blue-600" />
                      Rainfall Data
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      {environmentalData.rainfall}mm
                    </div>
                    <p className="text-sm text-gray-600">
                      Recent rainfall measurement affecting mosquito breeding patterns
                    </p>
                    <div className="mt-4 flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-blue-600" />
                      <span className="text-sm text-gray-600">
                        Impact on disease vectors: High
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-orange-600" />
                      Weather Alerts
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${environmentalData.floodAlert ? 'bg-red-500' : 'bg-green-500'}`}></div>
                        <span className="text-sm">
                          Flood Alert: {environmentalData.floodAlert ? 'Active' : 'None'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${environmentalData.heatwaveAlert ? 'bg-red-500' : 'bg-green-500'}`}></div>
                        <span className="text-sm">
                          Heatwave Alert: {environmentalData.heatwaveAlert ? 'Active' : 'None'}
                        </span>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-800">
                        Environmental conditions are suitable for vector-borne disease transmission
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Data Source and Analysis */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-pwc-blue" />
                      Data Source
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Source:</span>
                        <span className="text-sm font-medium">{environmentalData.dataSource}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Region:</span>
                        <span className="text-sm font-medium">{environmentalData.region}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Last Updated:</span>
                        <span className="text-sm font-medium">
                          {new Date(environmentalData.recordedAt).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-yellow-600" />
                      Disease Risk Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Vector-borne diseases:</span>
                        <Badge className="bg-red-100 text-red-800">High Risk</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Respiratory diseases:</span>
                        <Badge className="bg-yellow-100 text-yellow-800">Medium Risk</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Water-borne diseases:</span>
                        <Badge className="bg-green-100 text-green-800">Low Risk</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {!environmentalData && (
            <div className="text-center py-12">
              <CloudSun className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-700 mb-2">No Environmental Data</h3>
              <p className="text-gray-500">Environmental monitoring data is not available</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}