import { useQuery } from "@tanstack/react-query";
import NavHeader from "@/components/layout/nav-header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Download, 
  TrendingUp, 
  Calendar, 
  BarChart3, 
  Target,
  AlertTriangle,
  Activity
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function ReportsPage() {
  const { data: predictions = [] } = useQuery({
    queryKey: ["/api/dashboard/predictions"],
  });

  const { data: metrics } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: diseases = [] } = useQuery({
    queryKey: ["/api/dashboard/diseases"],
  });

  const generatePredictionReport = () => {
    const report = {
      title: "Disease Prediction Report",
      date: new Date().toISOString(),
      predictions: predictions.map((p: any) => ({
        disease: p.disease.name,
        riskLevel: p.riskLevel,
        confidence: p.confidence,
        predictedDate: p.predictedDate,
        region: p.region
      })),
      metrics: metrics
    };
    
    const dataStr = JSON.stringify(report, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `disease_prediction_report_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const generateEnvironmentalReport = () => {
    alert("Environmental report generation is not yet implemented");
  };

  const generateAnalyticsReport = () => {
    alert("Analytics report generation is not yet implemented");
  };

  const highRiskPredictions = predictions.filter((p: any) => p.riskLevel === 'high');
  const mediumRiskPredictions = predictions.filter((p: any) => p.riskLevel === 'medium');
  const lowRiskPredictions = predictions.filter((p: any) => p.riskLevel === 'low');

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <FileText className="h-8 w-8 text-pwc-blue" />
              Reports & Analytics
            </h1>
            <p className="mt-2 text-gray-600">
              Generate comprehensive reports and analytics for disease predictions
            </p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Total Predictions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {predictions.length}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Active disease predictions
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  High Risk Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">
                  {highRiskPredictions.length}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Require immediate attention
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Accuracy Rate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {metrics?.accuracy || 0}%
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Prediction accuracy
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  Diseases Tracked
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {diseases.length}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Different disease types
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Report Generation */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-pwc-blue" />
                  Prediction Reports
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Disease Prediction Summary</h4>
                      <p className="text-sm text-gray-600">Complete prediction analysis with risk levels</p>
                    </div>
                    <Button onClick={generatePredictionReport} className="pwc-blue text-white">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Environmental Impact Report</h4>
                      <p className="text-sm text-gray-600">Weather conditions and disease correlation</p>
                    </div>
                    <Button onClick={generateEnvironmentalReport} variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Generate
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Analytics Dashboard</h4>
                      <p className="text-sm text-gray-600">Detailed analytics and trends</p>
                    </div>
                    <Button onClick={generateAnalyticsReport} variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Generate
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-green-600" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {predictions.slice(0, 5).map((prediction: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-2 border-l-4 border-pwc-blue bg-gray-50">
                      <div>
                        <p className="font-medium text-sm">{prediction.disease.name}</p>
                        <p className="text-xs text-gray-600">
                          {new Date(prediction.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge className={cn(
                        "text-xs",
                        prediction.riskLevel === 'high' ? 'bg-red-500 text-white' :
                        prediction.riskLevel === 'medium' ? 'bg-yellow-500 text-white' :
                        'bg-green-500 text-white'
                      )}>
                        {prediction.riskLevel}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Risk Distribution */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <AlertTriangle className="h-5 w-5" />
                  High Risk ({highRiskPredictions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {highRiskPredictions.map((prediction: any) => (
                    <div key={prediction.id} className="p-2 bg-red-50 rounded border-l-4 border-red-500">
                      <p className="font-medium text-sm">{prediction.disease.name}</p>
                      <p className="text-xs text-gray-600">
                        Confidence: {Math.round(prediction.confidence * 100)}%
                      </p>
                    </div>
                  ))}
                  {highRiskPredictions.length === 0 && (
                    <p className="text-sm text-gray-500">No high risk predictions</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-600">
                  <Target className="h-5 w-5" />
                  Medium Risk ({mediumRiskPredictions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {mediumRiskPredictions.map((prediction: any) => (
                    <div key={prediction.id} className="p-2 bg-yellow-50 rounded border-l-4 border-yellow-500">
                      <p className="font-medium text-sm">{prediction.disease.name}</p>
                      <p className="text-xs text-gray-600">
                        Confidence: {Math.round(prediction.confidence * 100)}%
                      </p>
                    </div>
                  ))}
                  {mediumRiskPredictions.length === 0 && (
                    <p className="text-sm text-gray-500">No medium risk predictions</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-600">
                  <Activity className="h-5 w-5" />
                  Low Risk ({lowRiskPredictions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {lowRiskPredictions.map((prediction: any) => (
                    <div key={prediction.id} className="p-2 bg-green-50 rounded border-l-4 border-green-500">
                      <p className="font-medium text-sm">{prediction.disease.name}</p>
                      <p className="text-xs text-gray-600">
                        Confidence: {Math.round(prediction.confidence * 100)}%
                      </p>
                    </div>
                  ))}
                  {lowRiskPredictions.length === 0 && (
                    <p className="text-sm text-gray-500">No low risk predictions</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}