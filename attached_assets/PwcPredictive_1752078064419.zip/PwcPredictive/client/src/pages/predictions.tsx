import { useQuery } from "@tanstack/react-query";
import NavHeader from "@/components/layout/nav-header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Calendar, MapPin, AlertTriangle, Target, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export default function PredictionsPage() {
  const { data: predictions = [], isLoading } = useQuery({
    queryKey: ["/api/dashboard/predictions"],
    refetchInterval: 30000,
  });

  const { data: diseases = [] } = useQuery({
    queryKey: ["/api/dashboard/diseases"],
  });

  const getRiskBadgeColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "bg-red-500 text-white";
      case "medium":
        return "bg-yellow-500 text-white";
      case "low":
        return "bg-green-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavHeader />
        <div className="flex">
          <Sidebar />
          <main className="flex-1 p-8">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="h-48 bg-gray-200 rounded"></div>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <TrendingUp className="h-8 w-8 text-pwc-blue" />
              Disease Predictions
            </h1>
            <p className="mt-2 text-gray-600">
              AI-powered disease outbreak predictions for Maharashtra, India
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {predictions.map((prediction: any) => (
              <Card key={prediction.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{prediction.disease.name}</CardTitle>
                    <Badge className={cn("text-xs", getRiskBadgeColor(prediction.riskLevel))}>
                      {prediction.riskLevel.toUpperCase()} RISK
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Target className="h-4 w-4" />
                      <span>Confidence: {Math.round(prediction.confidence * 100)}%</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>Predicted: {new Date(prediction.predictedDate).toLocaleDateString()}</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{prediction.region}, {prediction.state}</span>
                    </div>

                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Contributing Factors:</h4>
                      <div className="flex flex-wrap gap-1">
                        {prediction.contributingFactors.map((factor: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {factor}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-700">
                        {prediction.geminiResponse.summary}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {predictions.length === 0 && (
            <div className="text-center py-12">
              <AlertTriangle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-700 mb-2">No Predictions Available</h3>
              <p className="text-gray-500 mb-4">Generate new predictions to see outbreak forecasts</p>
              <Button className="pwc-blue text-white hover:bg-pwc-dark-blue">
                <Zap className="h-4 w-4 mr-2" />
                Generate Predictions
              </Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}