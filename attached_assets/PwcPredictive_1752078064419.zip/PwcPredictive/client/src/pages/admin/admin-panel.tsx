import { useQuery } from "@tanstack/react-query";
import NavHeader from "@/components/layout/nav-header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Users, 
  Activity, 
  AlertTriangle, 
  Database, 
  ShieldCheck,
  Plus,
  Eye
} from "lucide-react";
import { useState } from "react";

export default function AdminPanel() {
  const [newEnvironmentalData, setNewEnvironmentalData] = useState({
    region: "",
    state: "",
    temperature: "",
    humidity: "",
    rainfall: "",
    windSpeed: "",
    airQuality: "",
    floodAlert: false,
    heatwaveAlert: false,
    dataSource: "Manual Entry",
  });

  const { data: allPredictions = [], isLoading: predictionsLoading } = useQuery({
    queryKey: ["/api/dashboard/predictions"],
    refetchInterval: 30000,
  });

  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    refetchInterval: 60000,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <ShieldCheck className="h-8 w-8 text-pwc-blue" />
              Admin Panel
            </h1>
            <p className="mt-2 text-gray-600">
              System administration and monitoring dashboard
            </p>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="predictions">Predictions</TabsTrigger>
              <TabsTrigger value="environment">Environment</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Total Users
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900">
                      {systemMetrics?.totalUsers || 0}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Registered users
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      Active Predictions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      {systemMetrics?.activePredictions || 0}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Current active predictions
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" />
                      High Risk Areas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      {systemMetrics?.highRiskAreas || 0}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Areas with high risk
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Database className="h-4 w-4" />
                      System Accuracy
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-blue-600">
                      {systemMetrics?.accuracy || 0}%
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Prediction accuracy
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Predictions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {allPredictions.slice(0, 5).map((prediction: any) => (
                      <div key={prediction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium">{prediction.disease?.name || 'Unknown Disease'}</p>
                          <p className="text-sm text-gray-600">{prediction.region}, {prediction.state}</p>
                        </div>
                        <Badge className={`${
                          prediction.riskLevel === 'high' ? 'bg-red-500' :
                          prediction.riskLevel === 'medium' ? 'bg-yellow-500' :
                          'bg-green-500'
                        } text-white`}>
                          {prediction.riskLevel}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="predictions" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>All Predictions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {allPredictions.map((prediction: any) => (
                      <div key={prediction.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{prediction.disease?.name || 'Unknown Disease'}</p>
                          <p className="text-sm text-gray-600">{prediction.region}, {prediction.state}</p>
                          <p className="text-xs text-gray-500">
                            Confidence: {Math.round(prediction.confidence * 100)}%
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${
                            prediction.riskLevel === 'high' ? 'bg-red-500' :
                            prediction.riskLevel === 'medium' ? 'bg-yellow-500' :
                            'bg-green-500'
                          } text-white`}>
                            {prediction.riskLevel}
                          </Badge>
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="environment" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Add Environmental Data</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="region">Region</Label>
                      <Input
                        id="region"
                        placeholder="e.g., Maharashtra"
                        value={newEnvironmentalData.region}
                        onChange={(e) => setNewEnvironmentalData({...newEnvironmentalData, region: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        placeholder="e.g., India"
                        value={newEnvironmentalData.state}
                        onChange={(e) => setNewEnvironmentalData({...newEnvironmentalData, state: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="temperature">Temperature (°C)</Label>
                      <Input
                        id="temperature"
                        type="number"
                        placeholder="e.g., 28.5"
                        value={newEnvironmentalData.temperature}
                        onChange={(e) => setNewEnvironmentalData({...newEnvironmentalData, temperature: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="humidity">Humidity (%)</Label>
                      <Input
                        id="humidity"
                        type="number"
                        placeholder="e.g., 75"
                        value={newEnvironmentalData.humidity}
                        onChange={(e) => setNewEnvironmentalData({...newEnvironmentalData, humidity: e.target.value})}
                      />
                    </div>
                  </div>
                  <Button className="mt-4 bg-pwc-blue hover:bg-pwc-dark-blue text-white">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Data
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="system" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>System Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="font-medium">Database</span>
                      </div>
                      <p className="text-sm text-gray-600">Connected and operational</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="font-medium">API Services</span>
                      </div>
                      <p className="text-sm text-gray-600">All endpoints responding</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}