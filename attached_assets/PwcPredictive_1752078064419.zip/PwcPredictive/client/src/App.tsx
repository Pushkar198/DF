import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import PredictionsPage from "@/pages/predictions";
import MedicinesPage from "@/pages/medicines";
import EnvironmentalPage from "@/pages/environmental";
import ReportsPage from "@/pages/reports";
import AdminPanel from "@/pages/admin/admin-panel";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/predictions" component={PredictionsPage} />
      <Route path="/medicines" component={MedicinesPage} />
      <Route path="/environmental" component={EnvironmentalPage} />
      <Route path="/reports" component={ReportsPage} />
      <Route path="/admin" component={AdminPanel} />
      <Route path="/" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
