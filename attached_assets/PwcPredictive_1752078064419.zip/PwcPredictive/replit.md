# PredictMed Insight - Replit MD

## Overview

PredictMed Insight is an AI-powered disease prediction platform that forecasts region-wise disease outbreaks using machine learning and Large Language Models (LLMs). The application combines historical disease data, environmental factors, and social media sentiment to provide healthcare professionals with actionable insights for preventive measures.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
- **Frontend**: React with TypeScript using Vite as the build tool
- **Backend**: Node.js with Express.js server
- **Database**: PostgreSQL with Drizzle ORM
- **AI Integration**: Google Gemini LLM for disease prediction analysis
- **Authentication**: Session-based authentication with bcrypt for password hashing

### Monorepo Structure
The application follows a monorepo pattern with clear separation:
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript schemas and types
- Database migrations managed through Drizzle Kit

## Key Components

### Frontend Architecture
- **Component Library**: Radix UI primitives with shadcn/ui styling
- **Styling**: Tailwind CSS with custom PwC brand theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Services
- **Database Layer**: Drizzle ORM with PostgreSQL using Neon serverless
- **Authentication**: Express sessions with PostgreSQL session store
- **AI Service**: Google Gemini integration for disease prediction
- **Data Services**: External API integrations for weather and health data
- **Prediction Engine**: Core service combining multiple data sources

### Database Schema
- **Users**: User accounts with role-based access (admin/user)
- **Diseases**: Disease catalog with symptoms and seasonal patterns
- **Medicines**: Medicine database with dosage and contraindications
- **Predictions**: AI-generated disease predictions with confidence scores
- **Alerts**: User notifications and warning system
- **Environmental Data**: Weather and environmental factors
- **Reports**: Generated analytics and historical data

## Data Flow

### Prediction Generation Process
1. **Data Collection**: Environmental data, historical disease patterns, social media sentiment
2. **AI Processing**: Gemini LLM analyzes combined data sources
3. **Prediction Storage**: Results stored in PostgreSQL with metadata
4. **Alert Generation**: High-risk predictions trigger user notifications
5. **Dashboard Updates**: Real-time updates via TanStack Query

### User Journey
1. **Registration**: Users register with organization details and region
2. **Dashboard**: Personalized predictions for user's geographic area
3. **Monitoring**: Real-time alerts and environmental factor tracking
4. **Medicine Recommendations**: AI-suggested treatments based on predictions
5. **Reporting**: Historical analysis and trend visualization

## External Dependencies

### Core Dependencies
- **@google/genai**: Google Gemini AI integration
- **@neondatabase/serverless**: PostgreSQL serverless database
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **bcrypt**: Password hashing
- **express-session**: Session management

### Development Tools
- **Vite**: Frontend build tool and dev server
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first CSS framework
- **Drizzle Kit**: Database migrations and schema management

### API Integrations
- **Google Gemini**: Disease prediction analysis
- **Weather APIs**: Environmental data (configured but not implemented)
- **Social Media APIs**: Sentiment analysis (structured but not active)

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express backend
- **Database**: Neon PostgreSQL serverless instance
- **Environment Variables**: DATABASE_URL, GEMINI_API_KEY, SESSION_SECRET

### Production Build
- **Frontend**: Vite build with optimized bundle
- **Backend**: ESBuild compilation for Node.js deployment
- **Database**: Automated migrations via Drizzle Kit
- **Session Storage**: PostgreSQL-backed session store

### Key Features
- **Real-time Predictions**: AI-powered disease outbreak forecasting
- **Regional Customization**: Location-specific insights and recommendations
- **Multi-role Support**: Different access levels for users and administrators
- **Responsive Design**: Mobile-first UI with PwC branding
- **Data Visualization**: Charts and metrics for trend analysis

The system is designed to be scalable and maintainable, with clear separation of concerns and type safety throughout the stack. The AI integration provides intelligent insights while the robust backend ensures reliable data management and user authentication.